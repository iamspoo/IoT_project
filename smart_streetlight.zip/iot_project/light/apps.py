from django.apps import AppConfig


class LightConfig(AppConfig):
    name = 'light'
